library(testthat)
library(sugrrants)

test_check("sugrrants")
