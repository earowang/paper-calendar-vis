## Comments

This is a re-submission of new release. I've fixed the DESCRIPTION file as follows:

* omitted the redundant 'with R' in Title
* omitted the redundant 'with R' in Description
* replaced double quotes with single quotes for package names and software names
* specified 'ggplot2' graphics for temporal data
* deleted "The goal of 'sugrrants' is to" in Description

Thanks.

## Test environments

* local OS X install, R 3.4.1
* ubuntu 14.04 (on travis-ci), R oldrel, release, devel
* win-builder (devel)

## R CMD check results

0 errors | 0 warnings | 1 note

* New submission

## Reverse dependencies

This is a new release, so there are no reverse dependencies.
